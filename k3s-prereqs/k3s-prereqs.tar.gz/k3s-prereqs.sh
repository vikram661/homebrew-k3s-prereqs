#!/bin/bash
set -e

echo "Installing K3s prerequisites..."

# Ensure Homebrew is available in non-interactive shells
export PATH="/opt/homebrew/bin:$PATH"

brew install yq

brew tap hashicorp/tap
brew install hashicorp/tap/hashicorp-vagrant

vagrant plugin install vagrant-hostmanager

echo "All prerequisites installed successfully!"
